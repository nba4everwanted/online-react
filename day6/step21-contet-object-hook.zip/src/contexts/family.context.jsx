import React from 'react';

const FamilyContext = React.createContext();

export default FamilyContext;