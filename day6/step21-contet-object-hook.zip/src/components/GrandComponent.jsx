import { useState } from "react";
import FamilyContext from "../contexts/family.context";
import CousinComponent from "./CousinComponent";
import ParentComponent from "./ParentComponent";

function GrandComponent(){
    let [state, setState] = useState({ version : 0, message : ''});
   
    let changeVersion = ()=>{
        setState({
            ...state,
            version : Math.round( Math.random() * 1000 )
        })
    }
    let changeMessage = ()=>{
        setState({
            ...state,
            message : new Date()+" is new message"
        })
    }
    return <div style={ { border : "2px solid black", padding : "10px", margin : "10px"} }>
                    <h1>Grand Parent Component | Version { state.version }</h1>
                    <button onClick={ changeVersion }>Change Version</button>
                    <button onClick={ changeMessage }>Change Message</button>
                    <FamilyContext.Provider value={ { ver : state.version, msg : state.message } } >
                        <ParentComponent/>
                        <CousinComponent/>
                    </FamilyContext.Provider>
                </div>
}

export default GrandComponent;