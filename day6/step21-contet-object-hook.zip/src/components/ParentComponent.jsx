import ChildComponent from "./ChildComponent";

function ParentComponent(){
    return <div style={ { border : "2px solid black", padding : "10px", margin : "10px"} }>
                <h1>Parent Component</h1>
                <ChildComponent/>
            </div>
}

export default ParentComponent;