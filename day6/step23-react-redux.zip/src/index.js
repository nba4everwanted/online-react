import ReactDOM from 'react-dom';
import HeroComp from './components/hero.component';
import HeroHookComp from './components/hero.component.hook';
import { Provider } from 'react-redux';
import store from './redux/store';

function MainApp(){
    return <div>
            <h1>Using React-Redux API</h1>
            <hr/>
            <Provider store={ store }>
                <HeroComp/>
                <HeroHookComp/>
            </Provider>
           </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));