import { createStore } from 'redux';
import heroReducer from './hero/reducers/hero.reducer';

const store = createStore( heroReducer );

export default store;