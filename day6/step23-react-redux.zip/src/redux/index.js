import addHero from './hero/action/hero.action';

export default addHero;