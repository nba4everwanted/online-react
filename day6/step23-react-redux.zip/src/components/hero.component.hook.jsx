import { useDispatch, useSelector } from 'react-redux';
import addHero from '../redux/index';

/* function HeroHookComp(props){
        return <div>
            <h1>Avenger's Enrollment Program with Hooks </h1>
            <h2>Number of Heroes Recruited : { props.numberOfHeroes } </h2>
            <button onClick={ props.addHero }>Add Avenger</button>
        </div>
} */

function HeroHookComp(){
    const numberOfHeroes = useSelector((state)=> state.numberOfHeroes);
    const dispatch = useDispatch();

    return <div>
        <h1>Avenger's Enrollment Program with Hooks </h1>
        <h2>Number of Heroes Recruited : { numberOfHeroes } </h2>
        <button onClick={ ()=>{ dispatch( addHero() )} }>Add Avenger</button>
    </div>
}

export default HeroHookComp;