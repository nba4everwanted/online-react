import { useEffect, useRef } from 'react';
import ReactDOM from 'react-dom';
import { createStore } from 'redux';

// actions
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";

// action creators
const addHero = ()=>{
    return {
        type : ADD_HERO
    }
}
const removeHero = ()=>{
    return {
        type : REMOVE_HERO
    }
}

// initial state
const initialState = {
    numberOfHeroes : 0
};

// reducers
const heroReducer = ( state = initialState, action )=>{
    switch(action.type){
        case ADD_HERO : return { numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVE_HERO : return { numberOfHeroes : state.numberOfHeroes - 1 }
        default : return state
    }
}

// store
const store = createStore(heroReducer);
// subscription
store.subscribe( ()=>{
    console.log( store.getState() );
})
// dispatching

function MainApp(){
    let herocount = useRef();
    useEffect(()=>{
        herocount.current.innerHTML = store.getState().numberOfHeroes;
    },[]);
    return <div>
            <h1>Using React Redux API</h1>
            <h2> Avengers recruited : <span ref={ herocount }></span></h2>
            <button onClick={ ()=>{ store.dispatch( addHero() ); herocount.current.innerHTML = store.getState().numberOfHeroes  }}>Add Hero</button>
            <button onClick={ ()=>{ store.dispatch( removeHero() ); herocount.current.innerHTML = store.getState().numberOfHeroes  }}>Remove Hero</button>
           </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));