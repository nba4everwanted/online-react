import { Component } from "react";
import FamilyContext from "../contexts/family.context";

class CousinComponent extends Component{
    render(){
        return <div style={ { border : "2px solid black", padding : "10px", margin : "10px"} }>
                    <h1>Cousin Component</h1>
                    <FamilyContext.Consumer>{(value)=>{
                        return <h3>Version : { value.ver } | Message : { value.msg }</h3>
                    }}</FamilyContext.Consumer>
                </div>
    }
}

export default CousinComponent;