import ReactDOM from 'react-dom';
import App from './components/app';

function MainApp(){
    return <div>
            <h1>Using hooks for Ajax</h1>
            <App/>
        </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));