import React from 'react';

const FamilyContext = React.createContext();

/* 
let FamilyProvider = FamilyContext.Provider;
let FamilyConsumer = FamilyContext.Consumer;

export {
    FamilyConsumer, 
    FamilyProvider
} 
*/

export default FamilyContext;