import { Component } from "react";
import FamilyContext from "../contexts/family.context";
import CousinComponent from "./CousinComponent";
import ParentComponent from "./ParentComponent";

class GrandComponent extends Component{
    state = {
        version : 101
    }
    changeVersion = ()=>{
        this.setState({
            version : Math.round( Math.random() * 1000 )
        })
    }
    render(){
        return <div style={ { border : "2px solid black", padding : "10px", margin : "10px"} }>
                    <h1>Grand Parent Component | Version { this.state.version }</h1>
                    <button onClick={ this.changeVersion }>Change Version</button>
                    <FamilyContext.Provider value={ this.state.version } >
                        <ParentComponent/>
                        <CousinComponent/>
                    </FamilyContext.Provider>
                </div>
    }
}

export default GrandComponent;