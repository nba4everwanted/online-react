import ReactDOM from 'react-dom';
import GrandComponent from './components/GrandComponent';

function MainApp(){
    return <div>
            <h1>Using Context API</h1>
                <GrandComponent/>
           </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));