import ReactDOM from 'react-dom';
import App from './components/app';
import useToggle from './hooks/useToggle';

function MainApp(){
    // let [show, changeShow] = useState(false);
    let [show, changeShow] = useToggle(false);
    return <div>
            <h1>Using hooks for Ajax</h1>
            <button onClick={ ()=>{ changeShow() }}> Show / Hide </button>
            { show ? <App/> : <h4>List Component Hidden</h4> }
           </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));