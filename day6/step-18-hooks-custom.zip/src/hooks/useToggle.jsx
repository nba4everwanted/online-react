import { useState } from "react";

function useToggle(initVal){
    const [state, setState] = useState(initVal);
    let toggle = ()=>{
        // state = !state;
        // console.log("state value is : ", state);
        setState(!state);
    }
   return [state, toggle];
}
export default useToggle;