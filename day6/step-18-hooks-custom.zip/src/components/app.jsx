import { useEffect, useState } from 'react';
import { fetchUrl } from 'fetch';

function App(){
    let [users, accessUsers] = useState([]); 
    useEffect(()=>{
        fetchUrl("https://jsonplaceholder.typicode.com/users",(error, meta, data)=>{
               if(error){
                    console.log("Error : ", error);
                }else{
                   accessUsers(JSON.parse(data))
                }
            })
    },[]);
    return <div>
                <h1>Making AJAX with React</h1>
                    <hr/>
                    <ol>
                        { users.map((user)=> <li key={user.id}>{ user.name }</li> ) }
                    </ol>
                </div>
}

export default App;