import { Component } from "react";

/*
must always return a single root node or use React.Fragment / <>
use className instead of class attribute
use htmlFor instead of for attribute
use defaultValue instead of value on inputs
close inputs and other orphan tags
all events must be camel cased / pascal case
inline style must use a config object
*/
class Herolist extends Component{
    render(){
        return <div className="box">
                    <h1>{ this.props.title } | Version : { this.props.version + 2 } </h1>
                    <ol>{ this.props.list.map((val, idx)=> <li key={idx}>{ val }</li>)}</ol>
                <label htmlFor="cb"> User Name : </label>
                <input id="cb" type="checkbox"/>
                <input type="text" defaultValue="vijay" />
                <button>Click Me</button>
                <article style={ { backgroundColor : "silver" } }>
                    Lorem ipsum dolor sit amet, consectetur adipisicing elit. Tempore, reprehenderit tempora laboriosam voluptatibus facere ipsam illo labore exercitationem sed, nulla commodi. Aspernatur sapiente expedita ipsum iste voluptate, commodi id cupiditate!
                </article>
               </div>
    }
}
export default Herolist;