import { Component } from "react";

class FirstComponent extends Component{
    state = {
        power : 1
    }
    render(){
        return <div>
                    <h1> Component Title : { this.props.title } | version : { this.props.version } </h1>
                    <h2> Power : { this.state.power }</h2>
                    <hr/>
                    { this.props.children }
                    <button onClick={ () => {
                        // alert("hello from the button");
                        this.setState({
                            power : this.state.power + 1
                        });
                    } }>Increase Power</button>
                </div>
    }
}

export default FirstComponent;