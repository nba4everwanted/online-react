import { Component } from 'react';
import ReactDOM from 'react-dom';
import FirstComponent from './components/first.component';

class App extends Component{
    render(){
        return <div>
                    <h1>React | Props</h1>
                    <FirstComponent title="My App 1 " version={101}>
                        <h1> Hello Child Component </h1>
                        <button> click me </button>
                    </FirstComponent>
                    <FirstComponent  version={102}>
                        <h1> Hello Child Component </h1>
                        <button> click me </button>
                    </FirstComponent>
                    <FirstComponent title="My App 3 " >
                        <h1> Hello Child Component </h1>
                        <button> click me </button>
                    </FirstComponent>
                </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));