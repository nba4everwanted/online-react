import React, { Component } from "react";

class FirstComponent extends Component{
    inputRef = React.createRef();
    setMessageOnParent = ()=>{
        this.props.setMessage( this.inputRef.current.value );
        this.inputRef.current.value = '';
    }
    render(){
        return <div>
                    <h1> Hello from Component </h1>
                    <h2> Power : { this.props.compPower } </h2>
                    <h2> Version : { this.props.ver } </h2>
                    <div>
                        { this.props.children }
                    </div>
                    <input ref={ this.inputRef } type="text" />
                    <button onClick={ this.setMessageOnParent }>Send Message</button>
                </div>
    }
}

export default FirstComponent;