import { Component } from 'react';
import ReactDOM from 'react-dom';
import FirstComponent from './components/child.component';

class App extends Component{
    state = { 
        power : 0,
        version : 100,
        childMessage : ''
    }
    increasePower = ()=>{
         this.setState({
             power : this.state.power + 1
         })
     }
    increaseVersion = ()=>{
         this.setState({
            version : this.state.version + 1
         })
     }
     accessChildMessage = (message)=>{
        this.setState({
            childMessage : message
        })
     }
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    <h3> Child Message is : { this.state.childMessage } </h3>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.increaseVersion }>Increase Version</button>
                   <hr/>
                    <FirstComponent setMessage={ this.accessChildMessage } ver={ this.state.version } compPower={ this.state.power }>
                            Lorem ipsum dolor sit amet consectetur adipisicing elit. Consectetur dolorem a, hic dolore ipsa commodi iusto libero corporis fugiat, laborum minima rem aut omnis quasi, accusantium quod ratione deleniti possimus!   
                    </FirstComponent>
                </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));