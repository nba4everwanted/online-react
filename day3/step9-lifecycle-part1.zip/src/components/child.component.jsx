import { Component } from "react";

class FirstComponent extends Component{
    state = {
        power : 0
    }
    constructor(){
        super();
        console.log("FirstComponent's constructor was called")
    }
    static getDerivedStateFromProps(){
        console.log("FirstComponent's getDerivedStateFromProps was called");
        return {
            power : 10
        }
    }
    componentDidMount(){
        console.log("FirstComponent's componentDidMount was called")
    }
    shouldComponentUpdate(){
        console.log("FirstComponent's shouldComponentUpdate was called");
        return true;
    }
    getSnapshotBeforeUpdate(){
        console.log("FirstComponent's getSnapshotBeforeUpdate was called")
    }
    componentDidUpdate(){
        console.log("FirstComponent's componentDidUpdate was called")
    }
    componentWillUnmount(){
        console.log("FirstComponent's componentDidUpdate was called")
    }

    render(){
        console.log("FirstComponent's render was called")
        return <div>
                    <h1> Hello from Component </h1>
                </div>
    }
}

export default FirstComponent;