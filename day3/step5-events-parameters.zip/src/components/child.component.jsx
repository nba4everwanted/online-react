import React, { Component } from "react";

class FirstComponent extends Component{
    state = {
        power : 0
    };

    inputRef = React.createRef();

    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    setPower = (event)=>{
        this.setState({
            power : Number( event.target.value )
        })
    }
    setPowerFromInput = ()=>{
        this.setState({
            power : Number( this.inputRef.current.value )
        })
    }
    render(){
        return <div>
                    <h1> Hello from Child Component </h1>
                    <h2>Power : { this.state.power }</h2>
                    <button onClick={ this.increasePower }>Increase Power</button>
                    <br/>
                    <input onInput={ (evt)=>{ this.setPower(evt) } } type="range" />
                    <br/>
                    <input ref={ this.inputRef } type="number" />
                    <button onClick={ this.setPowerFromInput }>Set Power from Input Number</button>
                </div>
    }
}

export default FirstComponent;