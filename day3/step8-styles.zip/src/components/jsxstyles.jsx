let boxWide = 400;

let boxStyle1 = { 
    backgroundColor : 'red', 
    width : boxWide+"px", 
    margin : '10px auto',
    fontFamily : 'arial',
    textAlign : 'justify',
    padding : '10px'
};

let boxStyle2 = { 
    backgroundColor : 'red', 
    width : (boxWide / 2)+"px", 
    margin : '10px auto',
    fontFamily : 'arial',
    textAlign : 'justify',
    padding : '10px'
};

export { boxStyle1, boxStyle2 };
