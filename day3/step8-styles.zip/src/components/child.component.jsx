import { Component } from "react";
// import { boxStyle1, boxStyle2 } from "./jsxstyles";
import './mystyle.css';
import client from './client.module.css';


class FirstComponent extends Component{
    
    render(){
        return <div>
{/*                    <article  style={ boxStyle1 }>
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores soluta quod error alias porro aspernatur fugiat voluptas temporibus, pariatur delectus nihil molestias placeat velit obcaecati facere amet perspiciatis labore itaque.
                   </article>
                   <article  style={ boxStyle2 }>
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores soluta quod error alias porro aspernatur fugiat voluptas temporibus, pariatur delectus nihil molestias placeat velit obcaecati facere amet perspiciatis labore itaque.
                   </article>
                   <article  style={ boxStyle1 }>
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores soluta quod error alias porro aspernatur fugiat voluptas temporibus, pariatur delectus nihil molestias placeat velit obcaecati facere amet perspiciatis labore itaque.
                   </article> */}

                    <article className="box">
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores soluta quod error alias porro aspernatur fugiat voluptas temporibus, pariatur delectus nihil molestias placeat velit obcaecati facere amet perspiciatis labore itaque.
                   </article>
                   <article className={client.box}>
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores soluta quod error alias porro aspernatur fugiat voluptas temporibus, pariatur delectus nihil molestias placeat velit obcaecati facere amet perspiciatis labore itaque.
                   </article>
                   <article className="box">
                       Lorem ipsum dolor sit amet consectetur adipisicing elit. Maiores soluta quod error alias porro aspernatur fugiat voluptas temporibus, pariatur delectus nihil molestias placeat velit obcaecati facere amet perspiciatis labore itaque.
                   </article>
               </div>
    }
}

export default FirstComponent;