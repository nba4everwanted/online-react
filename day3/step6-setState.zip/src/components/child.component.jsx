import { Component } from "react";

class FirstComponent extends Component{
    state = {
        power : 0,
        strongHeroMessage : '',
        weakHeroMessage : ''
    }
    increasePower = ()=>{
       /*  this.setState({
            power : this.state.power + 1
        });
        console.log("Power is : ",this.state.power); */

       /*  this.setState({
            power : this.state.power + 1
        }, function(){
            console.log("Power is : ",this.state.power);
        }); */

        this.setState((existingState,props)=>{
            console.log(existingState, props);
            return {
                power : existingState.power + 1
            }
        }, ()=>{
            console.log("Power is : ",this.state.power);
        });
    }
    render(){
        return <div>
                    <h1> { this.props.title } </h1>
                    <h2>Power : { this.state.power }</h2>
                    { this.state.power === 5 ? <h3>Hero's power is 5</h3> : <h3> Hero's power is not 5 </h3>}
                    <button onClick={ this.increasePower }>Increase Power</button>
                </div>
    }
}

export default FirstComponent;