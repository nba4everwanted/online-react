import { Component } from 'react';
import ReactDOM from 'react-dom';
import FirstComponent from './components/child.component';

class App extends Component{
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    <hr/>
                    <FirstComponent title="Child Component"/>
                </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));