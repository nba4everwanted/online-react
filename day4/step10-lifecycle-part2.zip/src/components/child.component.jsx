import { Component } from "react";

class FirstComponent extends Component{
    state = {
        power : 0
    }
    backupValue = []
    constructor(){
        super();
        console.log("FirstComponent's constructor was called")
    }
    static getDerivedStateFromProps(compProps, existingState){
        console.log("FirstComponent's getDerivedStateFromProps was called");
        return {
            power : compProps.appPower
        }
    }
    componentDidMount(){
        console.log("FirstComponent's componentDidMount was called")
    }
    shouldComponentUpdate(compProps, existingState){
        // console.log(arguments[0], arguments[1]);
        console.log("FirstComponent's shouldComponentUpdate was called");
        if(compProps.appPower <= 20){
            return true;
        }else{
            return false;
        }
    }
    getSnapshotBeforeUpdate(){
        console.log("FirstComponent's getSnapshotBeforeUpdate was called");
        this.backupValue.push(this.state);
        return true;
    }
    componentDidUpdate(){
        console.log("FirstComponent's componentDidUpdate was called")
    }
    componentWillUnmount(){
        console.log("FirstComponent's componentWillUnmount was called")
    }
    
    render(){
        console.log("FirstComponent's render was called")
        return <div>
                    <h1> Hello from Component </h1>
                    <h2>Power as set from parent component is : { this.props.appPower }</h2>
                    <h2>Power in the state of component is : { this.state.power }</h2>
                </div>
    }
}

export default FirstComponent;