import { Component } from 'react';
import ReactDOM from 'react-dom';

class PortalApp extends Component{
    render(){
        return ReactDOM.createPortal(this.props.children,document.getElementById("popup") )
    }
}
class App extends Component{
    state ={
        show : false
    }
    doShow = ()=>{
        this.setState({
            show : true
        })
    }
    doHide = ()=>{
        this.setState({
            show : false
        })
    }
    render(){
        if(this.state.show){
            return <div>
                    <h1>Welcome to your life</h1>
                    <PortalApp>
                        <div className="box">
                            <h2>Terms and Conditions</h2>
                            <p>
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Excepturi laudantium molestiae repudiandae, at exercitationem consectetur magnam eius quidem optio iure et rem nostrum veniam nesciunt! Quos in ut consequatur. Nisi.
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Excepturi laudantium molestiae repudiandae, at exercitationem consectetur magnam eius quidem optio iure et rem nostrum veniam nesciunt! Quos in ut consequatur. Nisi.
                            Lorem ipsum dolor, sit amet consectetur adipisicing elit. Excepturi laudantium molestiae repudiandae, at exercitationem consectetur magnam eius quidem optio iure et rem nostrum veniam nesciunt! Quos in ut consequatur. Nisi.
                            </p>
                            <button onClick={ this.doHide }>Hide</button>
                        </div>
                    </PortalApp>
                </div>
        }else{
            return <div>
                    <h1>Welcome to your life</h1>
                    <button onClick={ this.doShow }>Show</button>
                </div>
        }
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));