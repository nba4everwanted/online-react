import { Component } from "react";
import "./formstyle.css";

class FirstComponent extends Component{
    state = {
        username : "",
        userage : 0
    }
    manageUserName = (evt)=>{
        this.setState({
            username : evt.target.value
        })
    }
    manageUserAge = (evt)=>{
        this.setState({
            userage : evt.target.value
        })
    }
    submitHandler = (evt)=>{
        evt.preventDefault();
        // console.log(evt.target);
        if(this.state.userage < 18){
            alert("you are too young to join us")
        }else if( this.state.userage > 90){
            alert("you are too old to join us")
        }else{
            evt.target.submit();
        }
    }
    render(){
        return <div>
                    <h1> Hello from Component </h1>
                    <hr/>
                    <form action="#" method="get" onSubmit={ this.submitHandler }>
                        <label htmlFor="uname">User Name : </label>
                        <input name="uname" onInput={ (evt)=>{ this.manageUserName(evt) }} value={ this.state.username } type="text" id="uname" />
                        <br />
                        <label htmlFor="uage">User Age : </label>
                        <input name="uage" onInput={ (evt)=>{ this.manageUserAge(evt) }} value={ this.state.userage } type="number" id="uage" />
                        <br />
                        <button>Register</button>
                    </form>
                    <hr/>
                    <ul>
                        <li>User Name : { this.state.username }</li>
                        <li>User Age : { this.state.userage }</li>
                    </ul>
               </div>
    }
}

export default FirstComponent;