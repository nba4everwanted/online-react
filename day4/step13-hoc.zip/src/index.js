import { Component } from 'react';
import ReactDOM from 'react-dom';
import FirstComponent from './components/first.component';
import SecondComponent from './components/second.component';

class App extends Component{
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    <FirstComponent city="Bangalore" version={1001}/>
                    <SecondComponent city="Lagos" version={1002}/>
                </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));
