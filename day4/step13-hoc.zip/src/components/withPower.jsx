import { Component } from "react";

let WithPower = (OriginalComponent)=>{

    class TempComp extends Component{
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState({ power : this.state.power + 1 })
        }
        render() {
            // return <OriginalComponent city={ this.props.city } version={ this.props.version } incPow={ this.increasePower } pow={ this.state.power } title="Using HOC"/>;
            return <OriginalComponent {...this.props} incPow={ this.increasePower } pow={ this.state.power } title="Using HOC"/>;
        }
    }

    return TempComp
}

export default WithPower;