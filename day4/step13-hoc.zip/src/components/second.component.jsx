import { Component } from "react";
import WithPower from "./withPower";

class SecondComponent extends Component{
    
    render(){
        let { pow, title, incPow, version, city } = this.props;
        return <div>
                    <h1> Hello from Second Component </h1>
                    <h2>Power is : { pow }</h2>
                    <h3>Title : { title }</h3>
                    <h3>Version : { version }</h3>
                    <h3>City : { city }</h3>
                    <button onClick={ incPow }>Increase Power</button>
                </div>
    }
}

export default WithPower( SecondComponent );