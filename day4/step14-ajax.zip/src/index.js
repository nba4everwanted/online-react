import { Component } from 'react';
import ReactDOM from 'react-dom';
import { fetchUrl } from 'fetch';

class App extends Component{
    state = {
        users : []
    }
    componentDidMount(){
        fetchUrl("https://jsonplaceholder.typicode.com/users",(error, meta, data)=>{
            console.log(meta);   
            if(error){
                    console.log("Error : ", error);
                }else{
                    this.setState({
                        users : JSON.parse(data)
                    })
                }
            })
    }
    render(){
        return <div>
                    <h1>Making AJAX with React</h1>
                    <hr/>
                    <ol>
                        { this.state.users.map((user)=> <li key={user.id}>{ user.name }</li> ) }
                    </ol>
                </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));
