import { Component } from "react";
import ReactDOM from 'react-dom';
import ChildComp from "./child.component";
import FunChildComp from "./fun-child.component";

class MainApp extends Component{
    render(){
        return <div>
                    <h1>Welcome to your life</h1>
                    <ChildComp title="My Application 1" version={ 101 }/>
                    <hr/>
                    <ChildComp title="My Application 2"  version={ 102 }/>
                    <hr/>
                    <ChildComp />
                    <hr/>
                    <ChildComp />
                    <hr/>
                    <FunChildComp title="Fun Comp title" version={ 2002 } />
                    <hr/>
                    <FunChildComp />
                </div>
    }
}

ReactDOM.render(<MainApp/>, document.getElementById("root"))