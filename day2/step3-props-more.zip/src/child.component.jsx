import { Component } from "react";
import PropTypes from 'prop-types';

class ChildComp extends Component{
   /*  static propTypes = {
        title : PropTypes.string.isRequired,
        version : PropTypes.number.isRequired
    } */
    render(){
        return <div>
            <h2>Child Component</h2>
            <h3>Title : { this.props.title }</h3>
            <h3>Version : { this.props.version }</h3>
        </div>
    }
}

ChildComp.propTypes = {
    title : PropTypes.string.isRequired,
    version : PropTypes.number.isRequired
}

ChildComp.defaultProps = {
    title : "Default Title from Child Comp",
    version : 0
}

export default ChildComp;