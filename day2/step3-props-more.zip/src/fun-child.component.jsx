import PropTypes from 'prop-types';
/* function FunChildComp(props){
    let {title, version} = props;
    return <div>
                <h2>Function Child Component</h2>
                <h3>Title : { title }</h3>
                <h3>Version : { version }</h3>
            </div>
} */

function FunChildComp({title, version}){
    return <div>
                <h2>Function Child Component</h2>
                <h3>Title : { title }</h3>
                <h3>Version : { version }</h3>
            </div>
}

FunChildComp.propTypes = {
    title : PropTypes.string.isRequired,
    version : PropTypes.number.isRequired
}

FunChildComp.defaultProps = {
    title : "Default Title from Child Comp",
    version : 0
}

export default FunChildComp;