/* import { Component } from "react";

class FirstComponent extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    render(){
        return <div>
                    <h1> Hello from Component Power is : { this.state.power }</h1>
                    <button onClick={ this.increasePower }>Increase Power</button>
                </div>
    }
}

export default FirstComponent; */

import { useState } from "react";

function FirstComponent(){
/*    
    let [power, setState] = useState(0);
    let [title, setTitle] = useState('default title'); 
*/
    let [config, manageState] = useState({ power : 0, title : 'default title'});
   let increasePower = ()=> manageState({...config, power : config.power+1 });

    return <div>
                <h1> Hello from Hook Component Power is : { config.power }</h1>
                <h1> Title is : { config.title }</h1>
                <button onClick={ increasePower }>Increase Power</button>
                <button onClick={ ()=> manageState({...config, title : 'some new title'}) }>Change Title</button>
            </div>
}

export default FirstComponent;