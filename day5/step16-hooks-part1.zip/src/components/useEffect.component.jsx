import { useEffect } from "react";

function SecondComp({ pow, ver}){
  
    useEffect(()=>{
        console.log("Second Component was Mounted");
    },[]);

    useEffect(()=>{
        console.log("Second Component's Power was increased to ", pow);
    },[pow]);

    useEffect(()=>{
        return ()=>{
            console.log("Second Component is unmounted");
        }
    },[]) 



/*     useEffect(()=>{
        console.log("Second Component was Mounted");
        console.log("Second Component's Power was increased to ", pow);
        return ()=>{
            console.log("Second Component is unmounted");
        }
    },[pow]); */

    return <div>
                <h1>Use Effect Hook</h1>
                <h2>Power : { pow }</h2>
                <h2>Version : { ver }</h2>
            </div>
}

export default SecondComp;