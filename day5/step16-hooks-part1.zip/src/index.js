import { useState } from 'react';
import ReactDOM from 'react-dom';
import SecondComp from './components/useEffect.component';
import FirstComponent from './components/usestate.component';

function App(){
    let [ power, changePower ] = useState(0);
    let [ version, changeVersion ] = useState(101);
    return <div>
            <h1>Using hooks</h1>
            <FirstComponent/>
            <hr/>
            <button onClick={ ()=> changePower(power + 1 )}>Increase Power</button>
            <button onClick={ ()=> changeVersion( Math.round( Math.random() * 1000 ))}>Change Version</button>
            { power < 10 ? <SecondComp ver={ version } pow={ power }/> : <h2> Second Component Removed </h2>}
        </div>
}

ReactDOM.render(<App/>, document.getElementById("root"));