import { Component } from "react";

class Product1Comp extends Component{
    render(){
        return <div>
                    <h1> Product 1 Component </h1>
                    <h2>Type of Product is : { this.props.match.params.qty } </h2>
                </div>
    }
}

export default Product1Comp;