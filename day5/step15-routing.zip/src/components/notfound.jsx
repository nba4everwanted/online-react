import { Component } from "react";

class NotFoundComp extends Component{
    render(){
        return <div>
                    <h1> 404 | Requested Page Not Found Component </h1>
                </div>
    }
}

export default NotFoundComp;