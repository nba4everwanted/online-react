import { Component } from "react";

class Product2Comp extends Component{
    render(){
        return <div>
                    <h1> Product 2 Component </h1>
                    <h2>Type of Product is : { this.props.match.params.qty } </h2>
                </div>
    }
}

export default Product2Comp;