import { Component } from "react";

class LoginComp extends Component{
    render(){
        return <div>
                    <h1> Login Component </h1>
                </div>
    }
}

export default LoginComp;