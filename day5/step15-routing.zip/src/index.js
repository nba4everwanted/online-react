import { Component } from 'react';
import ReactDOM from 'react-dom';
import { BrowserRouter, Link, NavLink, Route, Switch } from 'react-router-dom';
import HomeComp from './components/home';
import LoginComp from './components/login';
import NotFoundComp from './components/notfound';
import Product1Comp from './components/product1';
import Product2Comp from './components/product2';
import './compStyle.css';

class App extends Component{
    state = {
        type : ''
    };
    changeQuantity = (evt)=>{
        this.setState({
            type : evt.target.value
        })
    };
    render(){
        return <div>
                    <h1>Routing in React | { this.state.type }</h1>
                    <input onInput={ this.changeQuantity } value={ this.state.type } type="text"/>
                    <hr/>
                    <BrowserRouter>
                        {/* <a href="/">Home</a> &nbsp; | &nbsp;
                        <a href="/login">Login</a> &nbsp;| &nbsp;
                        <a href="/product1">Product 1</a> &nbsp;| &nbsp;
                        <a href="/product2">Product 2</a> &nbsp;|&nbsp; 
                        <a href="/profile">Profile</a> */}

                        {/* <Link to="/">Home</Link> &nbsp; | &nbsp;
                        <Link to="/login">Login</Link> &nbsp;| &nbsp;
                        <Link to="/product1">Product 1</Link> &nbsp;| &nbsp;
                        <Link to="/product2">Product 2</Link> &nbsp;|&nbsp; 
                        <Link to="/profile">Profile</Link> */}

                        {
                            /* <NavLink activeStyle={ {color : 'papayawhip', backgroundColor: 'crimson'} } to="/login">Login</NavLink> &nbsp;| &nbsp; */
                        }
                        <NavLink exact activeClassName="boxer" to="/">Home</NavLink> &nbsp; | &nbsp;
                        <NavLink activeClassName="boxer" to="/login">Login</NavLink> &nbsp;| &nbsp;
                        <NavLink activeClassName="boxer" to={"/product1/"+this.state.type }>Product 1</NavLink> &nbsp;| &nbsp;
                        <NavLink activeClassName="boxer" to={"/product2/"+this.state.type }>Product 2</NavLink> &nbsp;|&nbsp; 
                        <NavLink activeClassName="boxer" to="/profile">Profile</NavLink>

                        <Switch>
                            <Route path="/" exact>
                                <HomeComp/>
                            </Route>
                            <Route path="/login">
                                <LoginComp/>
                            </Route>
                            <Route path="/product1/:qty" component={ Product1Comp } />
                            <Route path="/product2/:qty" component={ Product2Comp } />
                            <Route component={ NotFoundComp } />
                        </Switch>
                    </BrowserRouter>
                </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));
