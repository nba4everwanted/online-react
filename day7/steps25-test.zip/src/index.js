import { Component } from 'react';
import ReactDOM from 'react-dom';
import MainApp from './components/app';

class App extends Component{
    render(){
        return <div>
                   <MainApp/>
               </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));