import MainApp from "./app";

describe("Testing Main App", ()=>{
    let app = null;
    beforeEach(()=>{
        console.log("Before Each was called");
        app = new MainApp();
    })
    describe("Testing Power",()=>{
        test("Should check for power to be defined", ()=>{
            expect(app.state.power).toBeDefined();
        })
        test("Should check for power to be 5", ()=>{
            expect(app.state.power).toBe(5);
        })
        test("Should check for power to be less than 10", ()=>{
            expect(app.state.power).toBeLessThan(10);
        })
    })
    describe("Testing City",()=>{
        test("Should check for city to be defined", ()=>{
            expect(app.state.city).toBeDefined()
        })
        test("Should check for city to have 9 characters", ()=>{
            expect(app.state.city).toMatch(/\s{9}/)
        })
        test("Should check for city to be bangalore", ()=>{
            expect(app.state.city).toBe('bangalore')
        })
    })
    afterEach(()=>{
        console.log("After Each was called");
        app = null;
    })
})