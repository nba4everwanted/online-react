import { Component } from "react";

class MainApp extends Component{
    state = {
        power : 5,
        city : "bangalore"
    }
    render(){
        return <h1>Hello From App</h1>
    }
};

export default MainApp;