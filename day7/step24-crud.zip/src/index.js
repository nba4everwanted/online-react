import { Component } from 'react';
import ReactDOM from 'react-dom';
import Userlist from './components/userslist';

class App extends Component{
    render(){
        return <div className="container">
                    <Userlist/>
               </div>
    }
}

ReactDOM.render(<App/>, document.getElementById("root"));