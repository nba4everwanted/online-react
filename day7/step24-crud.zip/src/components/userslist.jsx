import { Component } from "react";
import axios from 'axios';

class Userlist extends Component {
    state = {
      title: "Users List Application",
      userslist: [],
      userfirstname: "",
      userlastname: "",
      userpower: "",
      usercity: "",
      edit_firstname: "",
      edit_lastname: "",
      edit_power: "",
      edit_city: "",
      edit_id: "",
      showEditBox : false
    };

  // READ REQUEST
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  componentDidMount(){
    this.reload();
  };
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // RELOAD DATA
    reload = () => {
      axios
        .get("http://localhost:1010/data")
        .then((res) => {
          this.setState({
            userslist: res.data,
          });
        })
        .catch((error) => {
          console.log(error);
        });
    };
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // CREATE HERO EVENTS
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  firstnameChangeHandler = (evt) => {
    this.setState({
      userfirstname: evt.target.value,
    });
  };
  lastnameChangeHandler = (evt) => {
    this.setState({
      userlastname: evt.target.value,
    });
  };
  powerChangeHandler = (evt) => {
    this.setState({
      userpower: evt.target.value,
    });
  };
  cityChangeHandler = (evt) => {
    this.setState({
      usercity: evt.target.value,
    });
  };
  submitHandler = (evt) => {
    evt.preventDefault();
    axios
      .post("http://localhost:1010/data", {
        firstname: this.state.userfirstname,
        lastname: this.state.userlastname,
        power: this.state.userpower,
        city: this.state.usercity,
      })
      .then((res) => {
        console.log(res.message);
        this.reload();
        this.setState({
          userfirstname: "",
          userlastname: "",
          userpower: "",
          usercity: "",
        });
      })
      .catch((error) => {
        console.log(error.message);
      });
  };
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // EDIT EVENT HANDLER
  edit_firstnameChangeHandler = (evt)=>{
    this.setState({
      edit_firstname : evt.target.value
    });
  }
  edit_lastnameChangeHandler = (evt)=>{
    this.setState({
      edit_lastname : evt.target.value
    });
  }
  edit_powerChangeHandler = (evt)=>{
    this.setState({
      edit_power : evt.target.value
    });
  }
  edit_cityChangeHandler = (evt)=>{
    this.setState({
      edit_city : evt.target.value
    });
  }
  editHandler = (args) =>{
    // console.log(args);

    axios.get("http://localhost:1010/edit/"+args).then( res => {
        this.setState({
          edit_firstname : res.data.firstname,
          edit_lastname : res.data.lastname,
          edit_power : res.data.power,
          edit_city : res.data.city,
          edit_id : res.data._id,
          showEditBox : true
        })
    })
 }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // SUBMIT AFTER EDIT
  submitEditedHero = (evt)=>{
    evt.preventDefault();
    axios.post("http://localhost:1010/edit/"+this.state.edit_id, {
        firstname : this.state.edit_firstname,
        lastname : this.state.edit_lastname,
        power : this.state.edit_power,
        city : this.state.edit_city
    }).then( res => {
      console.log(res);
        this.reload();
        this.setState({
          edit_firstname : "",
          edit_lastname : "",
          edit_power : "",
          edit_city : "",
          edit_id : "",
          showEditBox : false
       })
    })
}
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  // DELETE
  deleteHandler = (args) =>{
    axios.delete("http://localhost:1010/delete/"+args).then( (res) => {
        this.reload();
    })
  }
  //+++++++++++++++++++++++++++++++++++++++++++++++++++++++++
  render() {
    return (
      <div className="container">
        <h1 className="text-center">{this.state.title}</h1>
        <form onSubmit={this.submitHandler} action="#">
          <div>
          <label className="form-label" htmlFor="hfname">User First Name : </label>
          <input className="form-control" id="hfname" value={this.state.userfirstname} onChange={this.firstnameChangeHandler} />
          </div>
          <div>
          <label className="form-label" htmlFor="hlname">User Last Name : </label>
          <input className="form-control" id="hlname" value={this.state.userlastname} onChange={this.lastnameChangeHandler} />
          </div>
          <div>
          <label className="form-label" htmlFor="hpower">User Power : </label>
          <input className="form-control" id="hpower" value={this.state.userpower} onChange={this.powerChangeHandler}/>
          </div>
          <div>
          <label className="form-label" htmlFor="hcity">User City : </label>
          <input className="form-control" id="hcity" value={this.state.usercity} onChange={this.cityChangeHandler} />
          </div>
          <br />
          <button type="button" className="btn btn-primary" type="submit">Create User</button>
        </form>
        <hr />
        { this.state.showEditBox &&  <div> 
          <h1>Edit Hero</h1>
        <form onSubmit={this.submitEditedHero} action="#">
        <div>
          <label  className="form-label" htmlFor="hefname">User First Name : </label>
          <input  className="form-control" id="hefname" value={this.state.edit_firstname} onChange={this.edit_firstnameChangeHandler} />
        </div>
        <div>
          <label  className="form-label" htmlFor="helname">User Last Name : </label>
          <input  className="form-control" id="helname" value={this.state.edit_lastname} onChange={this.edit_lastnameChangeHandler} />
        </div>
        <div>
          <label  className="form-label" htmlFor="hepower">User Power : </label>
          <input  className="form-control" id="hepower" value={this.state.edit_power} onChange={this.edit_powerChangeHandler}/>
        </div>
        <div>
          <label  className="form-label" htmlFor="hecity">User City : </label>
          <input  className="form-control" id="hecity" value={this.state.edit_city}  onChange={this.edit_cityChangeHandler} />
        </div>
        <br />
          <button className="btn btn-primary" type="submit">Update User</button>
        </form>
        <hr />  
        </div> }
        <table className="table">
            <thead>
                <tr>
                    <th>Sl #</th>
                    <th>First Name</th>
                    <th>Last Name</th>
                    <th>Power</th>
                    <th>City</th>
                    <th>Edit</th>
                    <th>Delete</th>
                </tr>
            </thead>
            <tbody>
          {this.state.userslist.map((val, idx) => {
            return (
              <tr key={idx}>
                  <td>{idx+1}</td>
                  <td>{val.firstname}</td>
                  <td>{val.lastname}</td>
                  <td>{val.power}</td>
                  <td>{val.city}</td>
                  <td>
                    <button type="button" className="btn btn-warning" onClick={() => { this.editHandler(val._id);  }} >
                        Edit User
                    </button>
                  </td>
                  <td>
                    <button type="button" className="btn btn-danger" onClick={() => { this.deleteHandler(val._id); }} >  
                        Delete User 
                    </button>  
                  </td>
                </tr>
            );
          })}
        </tbody>
        </table>
      </div>
    );
  }
}

export default Userlist;
